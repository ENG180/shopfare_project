package com.shopfare.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.google.android.material.appbar.AppBarLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import android.widget.LinearLayout;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.HashMap;
import java.util.ArrayList;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.EditText;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayout.OnTabSelectedListener;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout.OnRefreshListener;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.widget.ScrollView;
import androidx.cardview.widget.CardView;
import de.hdodenhof.circleimageview.*;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import androidx.palette.*;
import androidmads.library.qrgenearator.*;
import com.google.zxing.*;
import uk.co.senab.photoview.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import androidmads.library.qrgenearator.QRGContents;
import androidmads.library.qrgenearator.QRGEncoder;
import androidmads.library.qrgenearator.QRGSaver;;

public class HomeActivity extends  AppCompatActivity  { 
	
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private HashMap<String, Object> map1 = new HashMap<>();
	private boolean search = false;
	private boolean Grid = false;
	private String qrc_string = "";
	private String qrc_type = "";
	private String inputValue = "";
	
	private ArrayList<HashMap<String, Object>> listmap2 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listmap1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> storelist = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> postmap = new ArrayList<>();
	
	private LinearLayout toolbar;
	private LinearLayout linear2;
	private BottomNavigationView bottomnavigation1;
	private ImageView imageview2;
	private LinearLayout linear7;
	private ImageView imageview4;
	private TextView textview2;
	private EditText edittext1;
	private ImageView imageview3;
	private LinearLayout linear3;
	private LinearLayout base;
	private LinearLayout layout3;
	private LinearLayout layout4;
	private LinearLayout layout5;
	private LinearLayout cod;
	private LinearLayout pager_cont;
	private TabLayout tabLayout;
	private LinearLayout base1;
	private LinearLayout trash;
	private LinearLayout linear4;
	private LinearLayout layout1;
	private LinearLayout layout2;
	private TextView textview1;
	private ImageView imageview1;
	private SwipeRefreshLayout swiperefreshlayout1;
	private RecyclerView recyclerview1;
	private GridView gridview1;
	private SwipeRefreshLayout swiperefreshlayout2;
	private RecyclerView recyclerview2;
	private GridView gridview2;
	private TextView textview11;
	private GridView gridview3;
	private LinearLayout linear8;
	private ImageView imageview5;
	private TextView textview3;
	private LinearLayout linear9;
	private ScrollView vscroll1;
	private CardView cardview1;
	private LinearLayout linear12;
	private CircleImageView circleimageview1;
	private LinearLayout linear13;
	private ImageView qrc_image;
	private TextView textview4;
	private TextView textview5;
	private LinearLayout linear11;
	private LinearLayout linear10;
	private RecyclerView recyclerview3;
	private CardView cardview2;
	private LinearLayout linear14;
	private TextView textview6;
	private TextView textview7;
	private LinearLayout linear16;
	private LinearLayout linear15;
	private LinearLayout linear17;
	private LinearLayout linear18;
	private ImageView imageview7;
	private TextView textview8;
	private ImageView imageview8;
	private TextView textview9;
	private ImageView imageview9;
	private TextView textview10;
	private LinearLayout _drawer_linear1;
	private TextView _drawer_textview1;
	
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		_app_bar = (AppBarLayout) findViewById(R.id._app_bar);
		_coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
		_toolbar = (Toolbar) findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = (DrawerLayout) findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(HomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = (LinearLayout) findViewById(R.id._nav_view);
		
		toolbar = (LinearLayout) findViewById(R.id.toolbar);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		bottomnavigation1 = (BottomNavigationView) findViewById(R.id.bottomnavigation1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview2 = (TextView) findViewById(R.id.textview2);
		edittext1 = (EditText) findViewById(R.id.edittext1);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		base = (LinearLayout) findViewById(R.id.base);
		layout3 = (LinearLayout) findViewById(R.id.layout3);
		layout4 = (LinearLayout) findViewById(R.id.layout4);
		layout5 = (LinearLayout) findViewById(R.id.layout5);
		cod = (LinearLayout) findViewById(R.id.cod);
		pager_cont = (LinearLayout) findViewById(R.id.pager_cont);
		tabLayout = (TabLayout) findViewById(R.id.tabLayout);
		base1 = (LinearLayout) findViewById(R.id.base1);
		trash = (LinearLayout) findViewById(R.id.trash);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		layout1 = (LinearLayout) findViewById(R.id.layout1);
		layout2 = (LinearLayout) findViewById(R.id.layout2);
		textview1 = (TextView) findViewById(R.id.textview1);
		imageview1 = (ImageView) findViewById(R.id.imageview1);
		swiperefreshlayout1 = (SwipeRefreshLayout) findViewById(R.id.swiperefreshlayout1);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		gridview1 = (GridView) findViewById(R.id.gridview1);
		swiperefreshlayout2 = (SwipeRefreshLayout) findViewById(R.id.swiperefreshlayout2);
		recyclerview2 = (RecyclerView) findViewById(R.id.recyclerview2);
		gridview2 = (GridView) findViewById(R.id.gridview2);
		textview11 = (TextView) findViewById(R.id.textview11);
		gridview3 = (GridView) findViewById(R.id.gridview3);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		textview3 = (TextView) findViewById(R.id.textview3);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		cardview1 = (CardView) findViewById(R.id.cardview1);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		circleimageview1 = (CircleImageView) findViewById(R.id.circleimageview1);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		qrc_image = (ImageView) findViewById(R.id.qrc_image);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		recyclerview3 = (RecyclerView) findViewById(R.id.recyclerview3);
		cardview2 = (CardView) findViewById(R.id.cardview2);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		textview6 = (TextView) findViewById(R.id.textview6);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview8 = (TextView) findViewById(R.id.textview8);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		textview9 = (TextView) findViewById(R.id.textview9);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		textview10 = (TextView) findViewById(R.id.textview10);
		_drawer_linear1 = (LinearLayout) _nav_view.findViewById(R.id.linear1);
		_drawer_textview1 = (TextView) _nav_view.findViewById(R.id.textview1);
		
		bottomnavigation1.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(MenuItem item) {
				final int _itemId = item.getItemId();
				if (_itemId == 0) {
					layout3.setVisibility(View.GONE);
					layout4.setVisibility(View.GONE);
					layout5.setVisibility(View.GONE);
					base.setVisibility(View.VISIBLE);
					textview2.setText("ShopFare");
				}
				if (_itemId == 1) {
					base.setVisibility(View.GONE);
					layout4.setVisibility(View.GONE);
					layout5.setVisibility(View.GONE);
					layout3.setVisibility(View.VISIBLE);
					textview2.setText("ShopFare");
				}
				if (_itemId == 2) {
					base.setVisibility(View.GONE);
					layout3.setVisibility(View.GONE);
					layout5.setVisibility(View.GONE);
					layout4.setVisibility(View.VISIBLE);
					textview2.setText("ShopFare");
				}
				if (_itemId == 3) {
					base.setVisibility(View.GONE);
					layout3.setVisibility(View.GONE);
					layout4.setVisibility(View.GONE);
					layout5.setVisibility(View.VISIBLE);
					textview2.setText("Profile");
				}
				return true;
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (_drawer.isDrawerOpen(GravityCompat.START)) {
					_drawer.closeDrawer(GravityCompat.START);
				}
				else {
					_drawer.openDrawer(GravityCompat.START);
				}
			}
		});
		
		imageview4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
				PopupMenu popup = new PopupMenu(HomeActivity.this, imageview4);
				
				Menu menu = popup.getMenu();
				menu.add("Option1");
				menu.add("Option2");
				
				
				popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
						
						public boolean onMenuItemClick(MenuItem item) {
								switch (item.getTitle().toString()) {
										case "Option1":
										return true;
										
										case "Option2":
										return true;
										
										default: return false;
								}
						}
				});
				
				
				popup.show();
				
			}
		});
		
		layout3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		gridview3.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				i.setClass(getApplicationContext(), CustomerActivity.class);
				startActivity(i);
			}
		});
		
		linear12.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SettingsActivity.class);
				startActivity(i);
			}
		});
		
		qrc_image.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear14.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), FinanceActivity.class);
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
		_tab();
		_toolbar.setVisibility(View.GONE);
		bottomnavigation1.getMenu().add(0, 0, 0, "Home").setIcon(R.drawable.ic_home_white);
		bottomnavigation1.getMenu().add(0, 1, 0, "Categories").setIcon(R.drawable.ic_view_module_white);
		bottomnavigation1.getMenu().add(0, 2, 0, "Cart List").setIcon(R.drawable.ic_add_shopping_cart_white);
		bottomnavigation1.getMenu().add(0, 3, 0, "Profile").setIcon(R.drawable.ic_account_circle_white);
		imageview4.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview3.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		imageview2.setColorFilter(0xFF000000, PorterDuff.Mode.MULTIPLY);
		linear7.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)2, (int)0, Color.TRANSPARENT, 0xFFF5F5F5));
		search = false;
		Grid = true;
		edittext1.setVisibility(View.GONE);
		recyclerview1.setVisibility(View.VISIBLE);
		_navigateColour("#43a047", "#ffffff");
		_design();
		_Song3();
		map1.clear();
		_Cat1();
		_Cat2();
		gridview3.setAdapter(new Gridview3Adapter(listmap1));
		((BaseAdapter)gridview3.getAdapter()).notifyDataSetChanged();
		recyclerview2.setLayoutManager(new LinearLayoutManager(this));
		recyclerview2.setAdapter(new Recyclerview2Adapter(listmap2));
		for(int _repeat70 = 0; _repeat70 < (int)(21); _repeat70++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", String.valueOf((long)(SketchwareUtil.getRandom((int)(1), (int)(7)))));
				postmap.add(_item);
			}
			
		}
		recyclerview1.setLayoutManager(new LinearLayoutManager(this));
		recyclerview1.setAdapter(new Recyclerview1Adapter(postmap));
		{
			HashMap<String, Object> _item = new HashMap<>();
			_item.put("store", "");
			storelist.add(_item);
		}
		
		recyclerview3.setLayoutManager(new LinearLayoutManager(this));
		recyclerview3.setAdapter(new Recyclerview3Adapter(storelist));
		_extra();
		inputValue = "find me";
		if (inputValue.length() > 0) {
			                    WindowManager manager = (WindowManager) getSystemService(WINDOW_SERVICE);
			
			Display display = manager.getDefaultDisplay();
			                    Point point = new Point();
			                    display.getSize(point);
			                    int width = point.x;
			                    int height = point.y;
			                    int smallerDimension = width < height ? width : height;
			                    smallerDimension = smallerDimension * 3 / 4;
			
			qrgEncoder = new QRGEncoder(
			                            inputValue, null,
			                            QRGContents.Type.TEXT,
			                            smallerDimension);
			                    qrgEncoder.setColorBlack(Color.BLACK);
			                    qrgEncoder.setColorWhite(Color.WHITE);
			                    try {
				                        bitmap = qrgEncoder.getBitmap();
				                        qrc_image.setImageBitmap(bitmap);
				                    } catch (Exception e) {
				                        e.printStackTrace();
				                    }
			                } else {
			                   
			                }
		            
		      
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	
	@Override
	public void onBackPressed() {
		if (_drawer.isDrawerOpen(GravityCompat.START)) {
			_drawer.closeDrawer(GravityCompat.START);
		}
		else {
			super.onBackPressed();
		}
	}
	public void _tab () {
		viewPager = new androidx.viewpager.widget.ViewPager(this); viewPager.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); 
		
		MyPagerAdapter adapter = new MyPagerAdapter(); viewPager.setAdapter(adapter); viewPager.setCurrentItem(0); base1.addView(viewPager);
		 
		tabLayout.setSelectedTabIndicatorColor(Color.parseColor("#4caf50"));
		 tabLayout.setTabTextColors(Color.parseColor("#212121"), Color.parseColor("#4caf50")); 
		
		
		 tabLayout.setupWithViewPager(viewPager);
		 
	} private class MyPagerAdapter extends androidx.viewpager.widget.PagerAdapter { public int getCount() { return 2; } @Override public Object instantiateItem(ViewGroup collection, int position) { LayoutInflater inflater = (LayoutInflater) getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE); View v = inflater.inflate(R.layout.empty, null);
			
			 LinearLayout container = (LinearLayout) v.findViewById(R.id.linear1);
			
			if (position == 0) { ViewGroup parent = (ViewGroup) layout1.getParent(); if (parent != null) { parent.removeView(layout1); 
					
				}container.addView(layout1); 
				
			} else if (position == 1) { ViewGroup parent = (ViewGroup) layout2.getParent(); if (parent != null) { parent.removeView(layout2);
					
				} container.addView(layout2);
				
				 } else if (position == 2) { ViewGroup parent = (ViewGroup) layout3.getParent(); if (parent != null) { parent.removeView(layout3);
					
				} container.addView(layout3); 
				
			} else if (position == 3) { ViewGroup parent = (ViewGroup) layout4.getParent(); if (parent != null) { parent.removeView(layout4);
					
				} container.addView(layout4); }
			
			else if (position == 4) { ViewGroup parent = (ViewGroup) layout5.getParent(); if (parent != null) { parent.removeView(layout5);
					
				} container.addView(layout5); }
			
			
			
			 collection.addView(v, 0); return v; 
			
		} @Override public void destroyItem(ViewGroup collection, int position, Object view) { collection.removeView((View) view); trash.addView((View) view);
			
		} @Override public CharSequence getPageTitle(int position) { switch (position) { case 0: return "FOLLOWING"; case 1: return "EXPLORE"; case 2: return "CHANTS";
				case 3: return "EBOOKS";
				case 4: return "QUOTES";
				 default: return null; }
			
			
		} @Override public boolean isViewFromObject(View arg0, Object arg1) { return arg0 == ((View) arg1);} @Override public Parcelable saveState() { return null; } } androidx.viewpager.widget.ViewPager viewPager;  private void foo() {
	}
	
	
	public void _Song3 () {
		map1 = new HashMap<>();
		map1.put("name", "Samsong");
		map1.put("ministry", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "more_11");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Sinach");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "sinach2");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Solomon Lange");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "more_5");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Sonnie Badu");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "more_6");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Steve Crown");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "steve_crown_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Tim Godfrey");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "tim_godfrey_2");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Tope Alabi");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "tope_alabi_2");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Travis Greene");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "travis_greene_4");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Victoria Orenze");
		map1.put("ministry", "");
		map1.put("about", "Koinonia Service");
		map1.put("aka", "MFM");
		map1.put("image", "victoria_orenze");
		map1.put("mark", String.valueOf((long)(0)));
		listmap2.add(map1);
	}
	
	
	public void _Cat1 () {
		map1 = new HashMap<>();
		map1.put("name", "Vehicles");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "car");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Properties");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "property");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Hotels");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "property");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Electronics & Gadgets");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "electronics");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Phones and Accessories");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "phone_4");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Tablets and Laptops");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "laptop_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Beauty And Body Care");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Fashion\n(male & female)");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "fashion");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Shoes (All Kinds)");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "shoes");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Seeking Work - CV's");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Services");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
	}
	
	
	public void _Cat2 () {
		map1 = new HashMap<>();
		map1.put("name", "Jobs");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Babies & kids");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "babies_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Animals & Pets");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "pets_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Food & Restaurant");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "food");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Health & Medicine");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Books");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Sports & Gymnastics");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Arts, Crafts & Hobbies");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "cat_1");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Equipments & Tools");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "equipment");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Repair & Construction");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "equipments");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
		map1 = new HashMap<>();
		map1.put("name", "Home & Furnitures");
		map1.put("tag", "");
		map1.put("about", "");
		map1.put("aka", "");
		map1.put("image", "home");
		map1.put("mark", String.valueOf((long)(0)));
		listmap1.add(map1);
	}
	
	
	public void _rippleRoundStroke (final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _extra () {
		
	}
	   private Bitmap bitmap;
	   private QRGEncoder qrgEncoder;
	{
	}
	
	
	public void _NavStatusBarColor (final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _navigateColour (final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _design () {
		_ClickEffect(imageview4);
		_ClickEffect(imageview3);
		_ClickEffect(imageview2);
	}
	
	
	public void _ClickEffect (final View _view) {
		TypedValue typedValue = new TypedValue();
		
		getApplicationContext().getTheme().resolveAttribute(16843868, typedValue, true);
		
		_view.setBackgroundResource(typedValue.resourceId);
		
		_view.setClickable(true);
	}
	
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.postc, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout divider_small = (LinearLayout) _view.findViewById(R.id.divider_small);
			final LinearLayout linear50 = (LinearLayout) _view.findViewById(R.id.linear50);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final androidx.cardview.widget.CardView cardview2 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview2);
			final LinearLayout bbar = (LinearLayout) _view.findViewById(R.id.bbar);
			final TextView text = (TextView) _view.findViewById(R.id.text);
			final LinearLayout linear69 = (LinearLayout) _view.findViewById(R.id.linear69);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final LinearLayout style_hor = (LinearLayout) _view.findViewById(R.id.style_hor);
			final LinearLayout style5 = (LinearLayout) _view.findViewById(R.id.style5);
			final LinearLayout style4 = (LinearLayout) _view.findViewById(R.id.style4);
			final LinearLayout style3 = (LinearLayout) _view.findViewById(R.id.style3);
			final LinearLayout video = (LinearLayout) _view.findViewById(R.id.video);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear55 = (LinearLayout) _view.findViewById(R.id.linear55);
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final LinearLayout linear8 = (LinearLayout) _view.findViewById(R.id.linear8);
			final LinearLayout leftside5 = (LinearLayout) _view.findViewById(R.id.leftside5);
			final LinearLayout rightside5 = (LinearLayout) _view.findViewById(R.id.rightside5);
			final ImageView leftside5upp = (ImageView) _view.findViewById(R.id.leftside5upp);
			final ImageView leftside5downn = (ImageView) _view.findViewById(R.id.leftside5downn);
			final ImageView rightside5up = (ImageView) _view.findViewById(R.id.rightside5up);
			final ImageView rightside5middle = (ImageView) _view.findViewById(R.id.rightside5middle);
			final LinearLayout rightside5down_linear = (LinearLayout) _view.findViewById(R.id.rightside5down_linear);
			final ImageView rightside5down = (ImageView) _view.findViewById(R.id.rightside5down);
			final TextView plus_image = (TextView) _view.findViewById(R.id.plus_image);
			final LinearLayout up4 = (LinearLayout) _view.findViewById(R.id.up4);
			final LinearLayout down4 = (LinearLayout) _view.findViewById(R.id.down4);
			final ImageView up4left = (ImageView) _view.findViewById(R.id.up4left);
			final ImageView up4right = (ImageView) _view.findViewById(R.id.up4right);
			final ImageView down4left = (ImageView) _view.findViewById(R.id.down4left);
			final ImageView down4right = (ImageView) _view.findViewById(R.id.down4right);
			final LinearLayout leftside3 = (LinearLayout) _view.findViewById(R.id.leftside3);
			final LinearLayout rightside3 = (LinearLayout) _view.findViewById(R.id.rightside3);
			final ImageView leftside3image = (ImageView) _view.findViewById(R.id.leftside3image);
			final ImageView rightside3up = (ImageView) _view.findViewById(R.id.rightside3up);
			final ImageView rightside3down = (ImageView) _view.findViewById(R.id.rightside3down);
			final VideoView videoview1 = (VideoView) _view.findViewById(R.id.videoview1);
			final LinearLayout linear71 = (LinearLayout) _view.findViewById(R.id.linear71);
			final LinearLayout linear72 = (LinearLayout) _view.findViewById(R.id.linear72);
			final LinearLayout linear75 = (LinearLayout) _view.findViewById(R.id.linear75);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			final TextView textview38 = (TextView) _view.findViewById(R.id.textview38);
			final ImageView imageview3 = (ImageView) _view.findViewById(R.id.imageview3);
			final TextView textview39 = (TextView) _view.findViewById(R.id.textview39);
			final ImageView imageview41 = (ImageView) _view.findViewById(R.id.imageview41);
			final TextView textview41 = (TextView) _view.findViewById(R.id.textview41);
			final LinearLayout linear77 = (LinearLayout) _view.findViewById(R.id.linear77);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final LinearLayout linear79 = (LinearLayout) _view.findViewById(R.id.linear79);
			final LinearLayout more_linear = (LinearLayout) _view.findViewById(R.id.more_linear);
			final ImageView imageview42 = (ImageView) _view.findViewById(R.id.imageview42);
			final TextView textview42 = (TextView) _view.findViewById(R.id.textview42);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview44 = (ImageView) _view.findViewById(R.id.imageview44);
			final TextView textview44 = (TextView) _view.findViewById(R.id.textview44);
			final TextView more_text = (TextView) _view.findViewById(R.id.more_text);
			final ImageView more = (ImageView) _view.findViewById(R.id.more);
			
			button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)0, 0xFFFFFFFF, 0xFF4CAF50));
			more_linear.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)10, (int)2, 0xFF4CAF50, Color.TRANSPARENT));
			style5.setVisibility(View.GONE);
			style4.setVisibility(View.GONE);
			style3.setVisibility(View.GONE);
			video.setVisibility(View.GONE);
			plus_image.setVisibility(View.INVISIBLE);
			imageview42.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			imageview6.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			imageview44.setColorFilter(0xFF607D8B, PorterDuff.Mode.MULTIPLY);
			more.setColorFilter(0xFF43A047, PorterDuff.Mode.MULTIPLY);
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 1) {
				rightside3.setVisibility(View.GONE);
				style3.setVisibility(View.VISIBLE);
				leftside3image.setImageResource(R.drawable.equipment);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 3) {
				rightside3.setVisibility(View.VISIBLE);
				style3.setVisibility(View.VISIBLE);
				leftside3image.setImageResource(R.drawable.sneakers);
				rightside3down.setImageResource(R.drawable.sneakers);
				rightside3up.setImageResource(R.drawable.sneakers);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 2) {
				down4.setVisibility(View.GONE);
				style4.setVisibility(View.VISIBLE);
				up4right.setImageResource(R.drawable.iphone2);
				up4left.setImageResource(R.drawable.iphone2);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 4) {
				down4.setVisibility(View.VISIBLE);
				style4.setVisibility(View.VISIBLE);
				up4right.setImageResource(R.drawable.shoe_2);
				up4left.setImageResource(R.drawable.shoe_2);
				down4right.setImageResource(R.drawable.shoe_2);
				down4left.setImageResource(R.drawable.shoe_2);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) == 5) {
				style5.setVisibility(View.VISIBLE);
				plus_image.setVisibility(View.INVISIBLE);
				leftside5upp.setImageResource(R.drawable.shoe_1);
				leftside5downn.setImageResource(R.drawable.shoe_2);
				rightside5up.setImageResource(R.drawable.shoe_1);
				rightside5middle.setImageResource(R.drawable.shoe_1);
				rightside5down.setImageResource(R.drawable.shoe_1);
			}
			if (Double.parseDouble(_data.get((int)_position).get("key").toString()) > 5) {
				style5.setVisibility(View.VISIBLE);
				plus_image.setVisibility(View.VISIBLE);
				leftside5upp.setImageResource(R.drawable.shoes);
				leftside5downn.setImageResource(R.drawable.shoes);
				rightside5up.setImageResource(R.drawable.shoes);
				rightside5middle.setImageResource(R.drawable.shoes);
				rightside5down.setImageResource(R.drawable.shoes);
				plus_image.setText("+ ".concat(String.valueOf((long)(Double.parseDouble(_data.get((int)_position).get("key").toString()) - 5)).concat(" more")));
				plus_image.setBackgroundColor(0x60000000);
			}
			if (_data.get((int)_position).get("key").toString().equals("video")) {
				video.setVisibility(View.VISIBLE);
			}
			more_linear.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), SellerpageActivity.class);
					startActivity(i);
				}
			});
			plus_image.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					SketchwareUtil.showMessage(getApplicationContext(), "in progress");
				}
			});
			style_hor.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), PreviewActivity.class);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Gridview1Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Gridview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom2, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			textview1.setText(_data.get((int)_position).get("name").toString());
			
			return _view;
		}
	}
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.custh, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear10 = (LinearLayout) _view.findViewById(R.id.linear10);
			final LinearLayout linear2 = (LinearLayout) _view.findViewById(R.id.linear2);
			final LinearLayout horiz_linear = (LinearLayout) _view.findViewById(R.id.horiz_linear);
			final LinearLayout vert_linear6 = (LinearLayout) _view.findViewById(R.id.vert_linear6);
			final LinearLayout linear43 = (LinearLayout) _view.findViewById(R.id.linear43);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout linear9 = (LinearLayout) _view.findViewById(R.id.linear9);
			final Button button1 = (Button) _view.findViewById(R.id.button1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			final TextView textview3 = (TextView) _view.findViewById(R.id.textview3);
			final HorizontalScrollView hscroll1 = (HorizontalScrollView) _view.findViewById(R.id.hscroll1);
			final LinearLayout linear4 = (LinearLayout) _view.findViewById(R.id.linear4);
			final LinearLayout l1 = (LinearLayout) _view.findViewById(R.id.l1);
			final LinearLayout l2 = (LinearLayout) _view.findViewById(R.id.l2);
			final LinearLayout l3 = (LinearLayout) _view.findViewById(R.id.l3);
			final LinearLayout l4 = (LinearLayout) _view.findViewById(R.id.l4);
			final LinearLayout l5 = (LinearLayout) _view.findViewById(R.id.l5);
			final androidx.cardview.widget.CardView lc1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.lc1);
			final LinearLayout hh1 = (LinearLayout) _view.findViewById(R.id.hh1);
			final ImageView imageview1 = (ImageView) _view.findViewById(R.id.imageview1);
			final TextView textview13 = (TextView) _view.findViewById(R.id.textview13);
			final TextView textview6 = (TextView) _view.findViewById(R.id.textview6);
			final TextView textview18 = (TextView) _view.findViewById(R.id.textview18);
			final TextView textview19 = (TextView) _view.findViewById(R.id.textview19);
			final androidx.cardview.widget.CardView hc2 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc2);
			final LinearLayout hh2 = (LinearLayout) _view.findViewById(R.id.hh2);
			final ImageView imageview7 = (ImageView) _view.findViewById(R.id.imageview7);
			final TextView textview14 = (TextView) _view.findViewById(R.id.textview14);
			final TextView textview7 = (TextView) _view.findViewById(R.id.textview7);
			final TextView textview20 = (TextView) _view.findViewById(R.id.textview20);
			final TextView textview21 = (TextView) _view.findViewById(R.id.textview21);
			final androidx.cardview.widget.CardView hc3 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc3);
			final LinearLayout hh3 = (LinearLayout) _view.findViewById(R.id.hh3);
			final ImageView imageview11 = (ImageView) _view.findViewById(R.id.imageview11);
			final TextView textview15 = (TextView) _view.findViewById(R.id.textview15);
			final TextView textview8 = (TextView) _view.findViewById(R.id.textview8);
			final TextView textview22 = (TextView) _view.findViewById(R.id.textview22);
			final TextView textview23 = (TextView) _view.findViewById(R.id.textview23);
			final androidx.cardview.widget.CardView hc4 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc4);
			final LinearLayout hh4 = (LinearLayout) _view.findViewById(R.id.hh4);
			final ImageView imageview12 = (ImageView) _view.findViewById(R.id.imageview12);
			final TextView textview16 = (TextView) _view.findViewById(R.id.textview16);
			final TextView textview9 = (TextView) _view.findViewById(R.id.textview9);
			final TextView textview24 = (TextView) _view.findViewById(R.id.textview24);
			final TextView textview25 = (TextView) _view.findViewById(R.id.textview25);
			final androidx.cardview.widget.CardView hc5 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.hc5);
			final LinearLayout hh5 = (LinearLayout) _view.findViewById(R.id.hh5);
			final ImageView imageview13 = (ImageView) _view.findViewById(R.id.imageview13);
			final TextView textview17 = (TextView) _view.findViewById(R.id.textview17);
			final TextView textview10 = (TextView) _view.findViewById(R.id.textview10);
			final TextView textview26 = (TextView) _view.findViewById(R.id.textview26);
			final TextView textview27 = (TextView) _view.findViewById(R.id.textview27);
			final LinearLayout v1 = (LinearLayout) _view.findViewById(R.id.v1);
			final LinearLayout v2 = (LinearLayout) _view.findViewById(R.id.v2);
			final LinearLayout linear30 = (LinearLayout) _view.findViewById(R.id.linear30);
			final LinearLayout linear32 = (LinearLayout) _view.findViewById(R.id.linear32);
			final androidx.cardview.widget.CardView cardview10 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview10);
			final LinearLayout linear31 = (LinearLayout) _view.findViewById(R.id.linear31);
			final ImageView imageview14 = (ImageView) _view.findViewById(R.id.imageview14);
			final TextView textview5 = (TextView) _view.findViewById(R.id.textview5);
			final androidx.cardview.widget.CardView cardview11 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview11);
			final LinearLayout linear33 = (LinearLayout) _view.findViewById(R.id.linear33);
			final ImageView imageview15 = (ImageView) _view.findViewById(R.id.imageview15);
			final TextView textview4 = (TextView) _view.findViewById(R.id.textview4);
			final LinearLayout linear39 = (LinearLayout) _view.findViewById(R.id.linear39);
			final LinearLayout linear40 = (LinearLayout) _view.findViewById(R.id.linear40);
			final androidx.cardview.widget.CardView cardview14 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview14);
			final LinearLayout linear41 = (LinearLayout) _view.findViewById(R.id.linear41);
			final ImageView imageview18 = (ImageView) _view.findViewById(R.id.imageview18);
			final TextView textview11 = (TextView) _view.findViewById(R.id.textview11);
			final androidx.cardview.widget.CardView cardview15 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview15);
			final LinearLayout linear42 = (LinearLayout) _view.findViewById(R.id.linear42);
			final ImageView imageview19 = (ImageView) _view.findViewById(R.id.imageview19);
			final TextView textview12 = (TextView) _view.findViewById(R.id.textview12);
			final LinearLayout linear44 = (LinearLayout) _view.findViewById(R.id.linear44);
			final LinearLayout linear5 = (LinearLayout) _view.findViewById(R.id.linear5);
			final HorizontalScrollView hscroll2 = (HorizontalScrollView) _view.findViewById(R.id.hscroll2);
			final LinearLayout linear45 = (LinearLayout) _view.findViewById(R.id.linear45);
			final TextView textview28 = (TextView) _view.findViewById(R.id.textview28);
			final TextView textview2 = (TextView) _view.findViewById(R.id.textview2);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			
			button1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)5, (int)2, 0xFF43A047, 0xFF4CAF50));
			button1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), CustomerActivity.class);
					startActivity(i);
				}
			});
			textview2.setElevation((float)5);
			textview1.setElevation((float)5);
			lc1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), SellerpageActivity.class);
					startActivity(i);
				}
			});
			hc2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), SellerpageActivity.class);
					startActivity(i);
				}
			});
			hc3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), SellerpageActivity.class);
					startActivity(i);
				}
			});
			hc4.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), SellerpageActivity.class);
					startActivity(i);
				}
			});
			hc5.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), SellerpageActivity.class);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Gridview2Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Gridview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom2, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			
			
			return _view;
		}
	}
	
	public class Gridview3Adapter extends BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public Gridview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.custom2, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final TextView textview1 = (TextView) _view.findViewById(R.id.textview1);
			
			textview1.setText(_data.get((int)_position).get("name").toString());
			try {
				if (_data.get((int)_position).containsKey("image")) {
					circleimageview1.setImageResource(getResources().getIdentifier(_data.get((int)_position).get("image").toString(), "drawable", getPackageName()));
				}
				else {
					
				}
			} catch (Exception e) {
				SketchwareUtil.showMessage(getApplicationContext(), "Error");
			}
			
			return _view;
		}
	}
	
	public class Recyclerview3Adapter extends RecyclerView.Adapter<Recyclerview3Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview3Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.custom3, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = (LinearLayout) _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview2 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview2);
			final LinearLayout linear14 = (LinearLayout) _view.findViewById(R.id.linear14);
			final ImageView imageview8 = (ImageView) _view.findViewById(R.id.imageview8);
			final TextView textview7 = (TextView) _view.findViewById(R.id.textview7);
			
			cardview2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), OpenshopActivity.class);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}