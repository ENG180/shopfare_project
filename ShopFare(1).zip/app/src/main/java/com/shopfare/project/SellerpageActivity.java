package com.shopfare.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import android.widget.ImageView;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.TextView;
import de.hdodenhof.circleimageview.*;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.widget.HorizontalScrollView;
import android.content.Intent;
import android.content.ClipData;
import android.net.Uri;
import java.util.Timer;
import java.util.TimerTask;
import android.view.View;
import androidx.palette.*;
import androidmads.library.qrgenearator.*;
import com.google.zxing.*;
import uk.co.senab.photoview.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;
import androidx.core.content.ContextCompat;
import androidx.core.app.ActivityCompat;
import android.Manifest;
import android.content.pm.PackageManager;
import androidx.core.widget.NestedScrollView;
import androidx.palette.graphics.Palette;

public class SellerpageActivity extends  AppCompatActivity  { 
	
	public final int REQ_CD_FP = 101;
	private Timer _timer = new Timer();
	
	private double n = 0;
	private double nn = 0;
	private  Color cll;
	private String vat = "";
	private String scrim_color = "";
	private String status_color = "";
	private double ani = 0;
	
	private ArrayList<String> list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> listm = new ArrayList<>();
	
	private LinearLayout linear0;
	private LinearLayout linear1;
	private LinearLayout bar_tap;
	private LinearLayout linear3;
	private ImageView imageview7;
	private LinearLayout search;
	private ImageView imageview8;
	private EditText edittext2;
	private ImageView imageview29;
	private ScrollView vscroll1;
	private LinearLayout linear7;
	private LinearLayout linear_banner1;
	private LinearLayout linear9;
	private LinearLayout linear34;
	private ImageView imageview3;
	private LinearLayout linear_namebanner;
	private TextView textview8;
	private LinearLayout linear14;
	private LinearLayout linear13;
	private TextView textview11;
	private TextView textview10;
	private TextView textview9;
	private LinearLayout linear_saldo1;
	private TextView textview18;
	private LinearLayout collections;
	private LinearLayout linear_storepics;
	private LinearLayout linear39;
	private LinearLayout linear_sa1;
	private LinearLayout linear38;
	private LinearLayout linear_sa2;
	private LinearLayout linear37;
	private LinearLayout linear_sa5;
	private CircleImageView circleimageview1;
	private TextView textview4;
	private LinearLayout linear_saldo3;
	private ImageView imageview26;
	private TextView textview5;
	private LinearLayout linear_saldo4;
	private ImageView imageview27;
	private TextView textview6;
	private ImageView imageview28;
	private TextView textview7;
	private RecyclerView recyclerview2;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear2;
	private LinearLayout col1;
	private LinearLayout col2;
	private LinearLayout col3;
	private LinearLayout col4;
	private LinearLayout col5;
	private LinearLayout linear_mall;
	private TextView textview_mall;
	private ImageView imageview30;
	private LinearLayout linear_choice;
	private TextView textview_choice;
	private ImageView imageview31;
	private LinearLayout linear_games;
	private TextView textview_games;
	private ImageView imageview32;
	private LinearLayout linear_top_up;
	private TextView textview_top_up;
	private ImageView imageview5;
	private LinearLayout linear_coupon;
	private TextView textview_coupon;
	private ImageView imageview6;
	private RecyclerView recyclerview1;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent i = new Intent();
	private TimerTask time;
	private Intent icall = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sellerpage);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		}
		else {
			initializeLogic();
		}
	}
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear0 = (LinearLayout) findViewById(R.id.linear0);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		bar_tap = (LinearLayout) findViewById(R.id.bar_tap);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		search = (LinearLayout) findViewById(R.id.search);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		edittext2 = (EditText) findViewById(R.id.edittext2);
		imageview29 = (ImageView) findViewById(R.id.imageview29);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear_banner1 = (LinearLayout) findViewById(R.id.linear_banner1);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		linear34 = (LinearLayout) findViewById(R.id.linear34);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		linear_namebanner = (LinearLayout) findViewById(R.id.linear_namebanner);
		textview8 = (TextView) findViewById(R.id.textview8);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		textview11 = (TextView) findViewById(R.id.textview11);
		textview10 = (TextView) findViewById(R.id.textview10);
		textview9 = (TextView) findViewById(R.id.textview9);
		linear_saldo1 = (LinearLayout) findViewById(R.id.linear_saldo1);
		textview18 = (TextView) findViewById(R.id.textview18);
		collections = (LinearLayout) findViewById(R.id.collections);
		linear_storepics = (LinearLayout) findViewById(R.id.linear_storepics);
		linear39 = (LinearLayout) findViewById(R.id.linear39);
		linear_sa1 = (LinearLayout) findViewById(R.id.linear_sa1);
		linear38 = (LinearLayout) findViewById(R.id.linear38);
		linear_sa2 = (LinearLayout) findViewById(R.id.linear_sa2);
		linear37 = (LinearLayout) findViewById(R.id.linear37);
		linear_sa5 = (LinearLayout) findViewById(R.id.linear_sa5);
		circleimageview1 = (CircleImageView) findViewById(R.id.circleimageview1);
		textview4 = (TextView) findViewById(R.id.textview4);
		linear_saldo3 = (LinearLayout) findViewById(R.id.linear_saldo3);
		imageview26 = (ImageView) findViewById(R.id.imageview26);
		textview5 = (TextView) findViewById(R.id.textview5);
		linear_saldo4 = (LinearLayout) findViewById(R.id.linear_saldo4);
		imageview27 = (ImageView) findViewById(R.id.imageview27);
		textview6 = (TextView) findViewById(R.id.textview6);
		imageview28 = (ImageView) findViewById(R.id.imageview28);
		textview7 = (TextView) findViewById(R.id.textview7);
		recyclerview2 = (RecyclerView) findViewById(R.id.recyclerview2);
		hscroll1 = (HorizontalScrollView) findViewById(R.id.hscroll1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		col1 = (LinearLayout) findViewById(R.id.col1);
		col2 = (LinearLayout) findViewById(R.id.col2);
		col3 = (LinearLayout) findViewById(R.id.col3);
		col4 = (LinearLayout) findViewById(R.id.col4);
		col5 = (LinearLayout) findViewById(R.id.col5);
		linear_mall = (LinearLayout) findViewById(R.id.linear_mall);
		textview_mall = (TextView) findViewById(R.id.textview_mall);
		imageview30 = (ImageView) findViewById(R.id.imageview30);
		linear_choice = (LinearLayout) findViewById(R.id.linear_choice);
		textview_choice = (TextView) findViewById(R.id.textview_choice);
		imageview31 = (ImageView) findViewById(R.id.imageview31);
		linear_games = (LinearLayout) findViewById(R.id.linear_games);
		textview_games = (TextView) findViewById(R.id.textview_games);
		imageview32 = (ImageView) findViewById(R.id.imageview32);
		linear_top_up = (LinearLayout) findViewById(R.id.linear_top_up);
		textview_top_up = (TextView) findViewById(R.id.textview_top_up);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		linear_coupon = (LinearLayout) findViewById(R.id.linear_coupon);
		textview_coupon = (TextView) findViewById(R.id.textview_coupon);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (false) {
					
				}
				else {
					
				}
			}
		});
		
		linear_storepics.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), StoreinfoActivity.class);
				startActivity(i);
			}
		});
		
		linear_sa5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "in progress");
			}
		});
		
		linear_saldo3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ChatActivity.class);
				startActivity(i);
			}
		});
		
		linear_saldo4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				icall.setAction(Intent.ACTION_DIAL);
				icall.setData(Uri.parse("tel:09058479630"));
				startActivity(icall);
			}
		});
	}
	
	private void initializeLogic() {
		_tab();
		for(int _repeat10 = 0; _repeat10 < (int)(50); _repeat10++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "collapsing items");
				listm.add(_item);
			}
			
		}
		recyclerview1.setLayoutManager(new GridLayoutManager(this,2,LinearLayoutManager.VERTICAL,false));
		recyclerview1.setAdapter(new Recyclerview1Adapter(listm));
		recyclerview2.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		recyclerview2.setAdapter(new Recyclerview2Adapter(listm));
		recyclerview2.setHasFixedSize(true);
		imageview26.setColorFilter(0xFF4CAF50, PorterDuff.Mode.MULTIPLY);
		imageview27.setColorFilter(0xFF4CAF50, PorterDuff.Mode.MULTIPLY);
		imageview28.setColorFilter(0xFF4CAF50, PorterDuff.Mode.MULTIPLY);
		imageview29.setColorFilter(0xFF9E9E9E, PorterDuff.Mode.MULTIPLY);
		_SetCornerRadius(search, 100, 2, "#e8f5e9");
		_SetCornerRadius(linear_banner1, 14, 4, "#FAFAFA");
		_SetCornerRadius(linear_saldo1, 30, 4, "#FAFAFA");
		_SetCornerRadius(linear_saldo1, 30, 4, "#fafafa");
		_SetCornerRadius(imageview3, 30, 4, "#FFFFFF");
		_SetCornerRadius(linear_saldo3, 5, 1, "#fafafa");
		_SetCornerRadius(linear_saldo4, 5, 1, "#fafafa");
		_SetCornerRadius(linear_sa5, 5, 1, "#fafafa");
		_NavStatusBarColor("#ffffff", "#ffffff");
		_Design();
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
		ani = 0;
		time = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						ani++;
						_animasi(ani % 3);
					}
				});
			}
		};
		_timer.scheduleAtFixedRate(time, (int)(0), (int)(2000));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu){
		MenuItem menuitem1 = menu.add(Menu.NONE, 0, Menu.NONE, "Search");
		menuitem1.setIcon(R.drawable.ic_search_white);
		menuitem1.setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
		menu.add(0, 1, 0, "Sort List");
		menu.add(0, 2, 0, "Cart List");
		return super.onCreateOptionsMenu(menu);
	}
	
	@Override
		public boolean onOptionsItemSelected(MenuItem item){
		final int _id = item.getItemId();
		final String _title = (String) item.getTitle();
		
		return super.onOptionsItemSelected(item);
	}
	public void _NavStatusBarColor (final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _tab () {
		
	}
	
	
	public void _ExtractColors () {
		
	}
	
	
	public void _ExtraFunctions () {
	}
	Bitmap bimage;
	{
	}
	
	
	public void _animasi (final double _ani) {
		if (ani == 0) {
			textview8.setText("Buy your babies kiddies toys🥰");
			textview11.setText(".");
			textview10.setText(".");
			textview9.setText(".");
			textview11.setTextColor(0xFF64B5F6);
			textview10.setTextColor(0xFFFFFFFF);
			textview9.setTextColor(0xFFFFFFFF);
			imageview3.setImageResource(R.drawable.babies_1);
			_imageviewrounded(imageview3);
		}
		if (ani == 1) {
			textview8.setText("Buy your Nice soft sneakers");
			textview11.setText(".");
			textview10.setText(".");
			textview9.setText(".");
			textview11.setTextColor(0xFF64B5F6);
			textview10.setTextColor(0xFFFFFFFF);
			textview9.setTextColor(0xFFFFFFFF);
			imageview3.setImageResource(R.drawable.sneakers);
			_imageviewrounded(imageview3);
		}
		if (ani == 2) {
			textview8.setText("Your clothes are not left out here Also Plain Ts🥰");
			textview11.setText(".");
			textview10.setText(".");
			textview9.setText(".");
			textview10.setTextColor(0xFF64B5F6);
			textview11.setTextColor(0xFFFFFFFF);
			textview9.setTextColor(0xFFFFFFFF);
			imageview3.setImageResource(R.drawable.cloth);
			_imageviewrounded(imageview3);
		}
		if (ani == 3) {
			textview8.setText("Buy iPhone 11 Pro");
			textview11.setText(".");
			textview10.setText(".");
			textview9.setText(".");
			textview9.setTextColor(0xFF64B5F6);
			textview10.setTextColor(0xFFFFFFFF);
			textview11.setTextColor(0xFFFFFFFF);
			imageview3.setImageResource(R.drawable.iphone);
			_imageviewrounded(imageview3);
		}
		if (ani == 4) {
			_imageviewrounded(imageview3);
			ani = 0;
		}
	}
	
	
	public void _imageviewrounded (final ImageView _imageview) {
		Bitmap bm = ((android.graphics.drawable.BitmapDrawable)_imageview.getDrawable()).getBitmap();
		
		_imageview.setImageBitmap(getRoundedCornerBitmap(bm, 14));
		
		// onCreate
	}
	public static Bitmap getRoundedCornerBitmap(Bitmap bitmap, int pixels) {
		Bitmap output = Bitmap.createBitmap(bitmap.getWidth(), bitmap.getHeight(), Bitmap.Config.ARGB_8888);
		Canvas canvas = new Canvas(output);
		final int color = 0xff424242;
		final Paint paint = new Paint();
		final Rect rect = new Rect(0, 0, bitmap.getWidth(), bitmap.getHeight());
		final RectF rectF = new RectF(rect);
		final float roundPx = pixels;
		paint.setAntiAlias(true);
		canvas.drawARGB(0, 0, 0, 0);
		paint.setColor(color);
		canvas.drawRoundRect(rectF, roundPx, roundPx, paint);
		paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_IN));
		canvas.drawBitmap(bitmap, rect, rect, paint);
		return output;
	}
	
	
	public void _SetCornerRadius (final View _view, final double _radius, final double _shadow, final String _color) {
		android.graphics.drawable.GradientDrawable ab = new android.graphics.drawable.GradientDrawable();
		
		ab.setColor(Color.parseColor(_color));
		ab.setCornerRadius((float) _radius);
		_view.setElevation((float) _shadow);
		_view.setBackground(ab);
		
		//Add More block in OnCreateActivity :
	}
	
	
	public void _Elevation (final View _view, final double _number) {
		
		_view.setElevation((int)_number);
	}
	
	
	public void _Design () {
		_Elevation(bar_tap, 10);
		_Icon_Colour(imageview29, "#4caf50");
		_Icon_Colour(imageview7, "#4caf50");
		_Icon_Colour(imageview8, "#4caf50");
		_ClickEffect(linear_saldo3);
		_ClickEffect(linear_saldo4);
		_ClickEffect(linear_sa5);
		_ClickEffect(imageview29);
		_ClickEffect(imageview7);
		_ClickEffect(imageview8);
		_ClickEffect(linear_storepics);
		_CardStyle(linear_mall, 8, 0, "#c8e6c9", true);
		_CardStyle(linear_choice, 8, 0, "#f5f5f5", true);
		_CardStyle(linear_games, 8, 0, "#f5f5f5", true);
		_CardStyle(linear_top_up, 8, 0, "#f5f5f5", true);
		_CardStyle(linear_coupon, 8, 0, "#f5f5f5", true);
		_SetCornerRadius(col1, 0, 8, "#f5f5f5");
		_SetCornerRadius(col2, 0, 8, "#f5f5f5");
		_SetCornerRadius(col3, 0, 8, "#f5f5f5");
		_SetCornerRadius(col4, 0, 8, "#f5f5f5");
		_SetCornerRadius(col5, 0, 8, "#f5f5f5");
	}
	
	
	public void _Icon_Colour (final ImageView _iconview, final String _colour) {
		_iconview.getDrawable().setColorFilter(Color.parseColor(_colour), PorterDuff.Mode.SRC_IN);
	}
	
	
	public void _ClickEffect (final View _view) {
		TypedValue typedValue = new TypedValue();
		
		getApplicationContext().getTheme().resolveAttribute(16843868, typedValue, true);
		
		_view.setBackgroundResource(typedValue.resourceId);
		
		_view.setClickable(true);
	}
	
	
	public void _CardStyle (final View _view, final double _shadow, final double _radius, final String _color, final boolean _touch) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_radius);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation((int)_shadow);}
		if (_touch) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration(100);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration(100);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration(100);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration(100);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public class Recyclerview2Adapter extends RecyclerView.Adapter<Recyclerview2Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview2Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.csellerh, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear7 = (LinearLayout) _view.findViewById(R.id.linear7);
			final LinearLayout linear_mall = (LinearLayout) _view.findViewById(R.id.linear_mall);
			final TextView textview_mall = (TextView) _view.findViewById(R.id.textview_mall);
			final ImageView imageview2 = (ImageView) _view.findViewById(R.id.imageview2);
			
			
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.csellerpage, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear12 = (LinearLayout) _view.findViewById(R.id.linear12);
			final androidx.cardview.widget.CardView cardview1 = (androidx.cardview.widget.CardView) _view.findViewById(R.id.cardview1);
			final LinearLayout linear_cargo1 = (LinearLayout) _view.findViewById(R.id.linear_cargo1);
			final LinearLayout linear_cargo2 = (LinearLayout) _view.findViewById(R.id.linear_cargo2);
			final ImageView image_cargo_1 = (ImageView) _view.findViewById(R.id.image_cargo_1);
			final TextView textview_cargo_1 = (TextView) _view.findViewById(R.id.textview_cargo_1);
			final LinearLayout linear21 = (LinearLayout) _view.findViewById(R.id.linear21);
			final TextView cargo_star_1 = (TextView) _view.findViewById(R.id.cargo_star_1);
			final TextView money_1 = (TextView) _view.findViewById(R.id.money_1);
			final ImageView image_cargo_2 = (ImageView) _view.findViewById(R.id.image_cargo_2);
			final TextView textview_cargo_2 = (TextView) _view.findViewById(R.id.textview_cargo_2);
			final LinearLayout linear22 = (LinearLayout) _view.findViewById(R.id.linear22);
			final TextView cargo_star_2 = (TextView) _view.findViewById(R.id.cargo_star_2);
			final TextView money_2 = (TextView) _view.findViewById(R.id.money_2);
			final LinearLayout productlin1 = (LinearLayout) _view.findViewById(R.id.productlin1);
			final ImageView image_cargo_4 = (ImageView) _view.findViewById(R.id.image_cargo_4);
			final TextView textview_cargo_4 = (TextView) _view.findViewById(R.id.textview_cargo_4);
			final LinearLayout linear24 = (LinearLayout) _view.findViewById(R.id.linear24);
			final TextView cargo_star_4 = (TextView) _view.findViewById(R.id.cargo_star_4);
			final LinearLayout linear36 = (LinearLayout) _view.findViewById(R.id.linear36);
			final TextView money_4 = (TextView) _view.findViewById(R.id.money_4);
			final TextView textview23 = (TextView) _view.findViewById(R.id.textview23);
			
			_ClickEffect(productlin1);
			productlin1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), PreviewActivity.class);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}