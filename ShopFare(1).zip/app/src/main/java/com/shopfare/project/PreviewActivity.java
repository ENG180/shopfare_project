package com.shopfare.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import android.widget.LinearLayout;
import android.webkit.WebView;
import android.webkit.WebSettings;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import de.hdodenhof.circleimageview.*;
import android.animation.ObjectAnimator;
import android.view.animation.LinearInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.BounceInterpolator;
import android.content.Intent;
import android.net.Uri;
import android.view.View;
import com.bumptech.glide.Glide;
import androidx.palette.*;
import androidmads.library.qrgenearator.*;
import com.google.zxing.*;
import uk.co.senab.photoview.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class PreviewActivity extends  AppCompatActivity  { 
	
	
	private LinearLayout linear0;
	private LinearLayout linear_webview;
	private LinearLayout viewBar;
	private LinearLayout background;
	private LinearLayout nav;
	private WebView webview1;
	private ImageView back;
	private LinearLayout linear4;
	private ImageView imageview10;
	private ImageView imageview3;
	private ScrollView vscroll1;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear5;
	private LinearLayout linear50;
	private LinearLayout linear6;
	private LinearLayout linear7;
	private LinearLayout linear51;
	private LinearLayout linear8;
	private LinearLayout linear18;
	private LinearLayout linear28;
	private ImageView image;
	private TextView money;
	private TextView textview_cargo;
	private LinearLayout linear49;
	private TextView cargo_star;
	private ImageView imageview14;
	private TextView textview27;
	private LinearLayout lod50;
	private LinearLayout lod100;
	private LinearLayout linear55;
	private LinearLayout choice_more;
	private TextView textview28;
	private TextView textview29;
	private TextView textview30;
	private ImageView imageview15;
	private TextView textview4;
	private TextView textview5;
	private ImageView imageview4;
	private TextView textview6;
	private LinearLayout linear9;
	private ImageView imageview5;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private TextView textview8;
	private ImageView imageview7;
	private TextView textview9;
	private TextView textview10;
	private LinearLayout linear52;
	private TextView textview7;
	private LinearLayout linear10;
	private ImageView imageview6;
	private LinearLayout linear16;
	private LinearLayout linear17;
	private TextView textview12;
	private TextView textview13;
	private ImageView imageview11;
	private TextView textview11;
	private ImageView imageview12;
	private TextView textview17;
	private LinearLayout linear19;
	private LinearLayout linear20;
	private TextView textview18;
	private LinearLayout linear22;
	private TextView textview19;
	private LinearLayout linear21;
	private CircleImageView circleimageview1;
	private TextView textview20;
	private LinearLayout linear23;
	private LinearLayout linear24;
	private LinearLayout linear25;
	private LinearLayout linear26;
	private LinearLayout linear27;
	private TextView textview21;
	private TextView textview22;
	private TextView textview23;
	private TextView textview24;
	private TextView textview25;
	private TextView textview26;
	private LinearLayout linear29;
	private LinearLayout linear30;
	private LinearLayout linear31;
	private LinearLayout linear32;
	private TextView textview_recommend;
	private LinearLayout recommend;
	private TextView textview_good;
	private LinearLayout good;
	private LinearLayout recommend_page;
	private LinearLayout good_page;
	private LinearLayout linear37;
	private LinearLayout linear38;
	private LinearLayout linear39;
	private LinearLayout linear40;
	private LinearLayout cargo1;
	private TextView money_1;
	private ImageView imageview_cargo1;
	private LinearLayout cargo2;
	private TextView money_2;
	private ImageView imageview_cargo2;
	private LinearLayout linear41;
	private LinearLayout linear42;
	private LinearLayout cargo3;
	private TextView money_3;
	private ImageView imageview_cargo3;
	private LinearLayout cargo4;
	private TextView money_4;
	private ImageView imageview_cargo4;
	private LinearLayout linear43;
	private LinearLayout linear44;
	private LinearLayout linear45;
	private LinearLayout linear46;
	private LinearLayout cargo5;
	private TextView money_5;
	private ImageView imageview_cargo5;
	private LinearLayout cargo6;
	private TextView money_6;
	private ImageView imageview_cargo6;
	private LinearLayout linear47;
	private LinearLayout linear48;
	private LinearLayout cargo7;
	private TextView money_7;
	private ImageView imageview_cargo7;
	private LinearLayout cargo8;
	private TextView money_8;
	private ImageView imageview_cargo8;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private LinearLayout linear15;
	private ImageView imageview8;
	private TextView textview14;
	private TextView textview16;
	private ImageView imageview9;
	private TextView textview15;
	
	private ObjectAnimator Anima = new ObjectAnimator();
	private ObjectAnimator Anima2 = new ObjectAnimator();
	private Intent i = new Intent();
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.preview);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		linear0 = (LinearLayout) findViewById(R.id.linear0);
		linear_webview = (LinearLayout) findViewById(R.id.linear_webview);
		viewBar = (LinearLayout) findViewById(R.id.viewBar);
		background = (LinearLayout) findViewById(R.id.background);
		nav = (LinearLayout) findViewById(R.id.nav);
		webview1 = (WebView) findViewById(R.id.webview1);
		webview1.getSettings().setJavaScriptEnabled(true);
		webview1.getSettings().setSupportZoom(true);
		back = (ImageView) findViewById(R.id.back);
		linear4 = (LinearLayout) findViewById(R.id.linear4);
		imageview10 = (ImageView) findViewById(R.id.imageview10);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		linear3 = (LinearLayout) findViewById(R.id.linear3);
		linear5 = (LinearLayout) findViewById(R.id.linear5);
		linear50 = (LinearLayout) findViewById(R.id.linear50);
		linear6 = (LinearLayout) findViewById(R.id.linear6);
		linear7 = (LinearLayout) findViewById(R.id.linear7);
		linear51 = (LinearLayout) findViewById(R.id.linear51);
		linear8 = (LinearLayout) findViewById(R.id.linear8);
		linear18 = (LinearLayout) findViewById(R.id.linear18);
		linear28 = (LinearLayout) findViewById(R.id.linear28);
		image = (ImageView) findViewById(R.id.image);
		money = (TextView) findViewById(R.id.money);
		textview_cargo = (TextView) findViewById(R.id.textview_cargo);
		linear49 = (LinearLayout) findViewById(R.id.linear49);
		cargo_star = (TextView) findViewById(R.id.cargo_star);
		imageview14 = (ImageView) findViewById(R.id.imageview14);
		textview27 = (TextView) findViewById(R.id.textview27);
		lod50 = (LinearLayout) findViewById(R.id.lod50);
		lod100 = (LinearLayout) findViewById(R.id.lod100);
		linear55 = (LinearLayout) findViewById(R.id.linear55);
		choice_more = (LinearLayout) findViewById(R.id.choice_more);
		textview28 = (TextView) findViewById(R.id.textview28);
		textview29 = (TextView) findViewById(R.id.textview29);
		textview30 = (TextView) findViewById(R.id.textview30);
		imageview15 = (ImageView) findViewById(R.id.imageview15);
		textview4 = (TextView) findViewById(R.id.textview4);
		textview5 = (TextView) findViewById(R.id.textview5);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview6 = (TextView) findViewById(R.id.textview6);
		linear9 = (LinearLayout) findViewById(R.id.linear9);
		imageview5 = (ImageView) findViewById(R.id.imageview5);
		linear11 = (LinearLayout) findViewById(R.id.linear11);
		linear12 = (LinearLayout) findViewById(R.id.linear12);
		textview8 = (TextView) findViewById(R.id.textview8);
		imageview7 = (ImageView) findViewById(R.id.imageview7);
		textview9 = (TextView) findViewById(R.id.textview9);
		textview10 = (TextView) findViewById(R.id.textview10);
		linear52 = (LinearLayout) findViewById(R.id.linear52);
		textview7 = (TextView) findViewById(R.id.textview7);
		linear10 = (LinearLayout) findViewById(R.id.linear10);
		imageview6 = (ImageView) findViewById(R.id.imageview6);
		linear16 = (LinearLayout) findViewById(R.id.linear16);
		linear17 = (LinearLayout) findViewById(R.id.linear17);
		textview12 = (TextView) findViewById(R.id.textview12);
		textview13 = (TextView) findViewById(R.id.textview13);
		imageview11 = (ImageView) findViewById(R.id.imageview11);
		textview11 = (TextView) findViewById(R.id.textview11);
		imageview12 = (ImageView) findViewById(R.id.imageview12);
		textview17 = (TextView) findViewById(R.id.textview17);
		linear19 = (LinearLayout) findViewById(R.id.linear19);
		linear20 = (LinearLayout) findViewById(R.id.linear20);
		textview18 = (TextView) findViewById(R.id.textview18);
		linear22 = (LinearLayout) findViewById(R.id.linear22);
		textview19 = (TextView) findViewById(R.id.textview19);
		linear21 = (LinearLayout) findViewById(R.id.linear21);
		circleimageview1 = (CircleImageView) findViewById(R.id.circleimageview1);
		textview20 = (TextView) findViewById(R.id.textview20);
		linear23 = (LinearLayout) findViewById(R.id.linear23);
		linear24 = (LinearLayout) findViewById(R.id.linear24);
		linear25 = (LinearLayout) findViewById(R.id.linear25);
		linear26 = (LinearLayout) findViewById(R.id.linear26);
		linear27 = (LinearLayout) findViewById(R.id.linear27);
		textview21 = (TextView) findViewById(R.id.textview21);
		textview22 = (TextView) findViewById(R.id.textview22);
		textview23 = (TextView) findViewById(R.id.textview23);
		textview24 = (TextView) findViewById(R.id.textview24);
		textview25 = (TextView) findViewById(R.id.textview25);
		textview26 = (TextView) findViewById(R.id.textview26);
		linear29 = (LinearLayout) findViewById(R.id.linear29);
		linear30 = (LinearLayout) findViewById(R.id.linear30);
		linear31 = (LinearLayout) findViewById(R.id.linear31);
		linear32 = (LinearLayout) findViewById(R.id.linear32);
		textview_recommend = (TextView) findViewById(R.id.textview_recommend);
		recommend = (LinearLayout) findViewById(R.id.recommend);
		textview_good = (TextView) findViewById(R.id.textview_good);
		good = (LinearLayout) findViewById(R.id.good);
		recommend_page = (LinearLayout) findViewById(R.id.recommend_page);
		good_page = (LinearLayout) findViewById(R.id.good_page);
		linear37 = (LinearLayout) findViewById(R.id.linear37);
		linear38 = (LinearLayout) findViewById(R.id.linear38);
		linear39 = (LinearLayout) findViewById(R.id.linear39);
		linear40 = (LinearLayout) findViewById(R.id.linear40);
		cargo1 = (LinearLayout) findViewById(R.id.cargo1);
		money_1 = (TextView) findViewById(R.id.money_1);
		imageview_cargo1 = (ImageView) findViewById(R.id.imageview_cargo1);
		cargo2 = (LinearLayout) findViewById(R.id.cargo2);
		money_2 = (TextView) findViewById(R.id.money_2);
		imageview_cargo2 = (ImageView) findViewById(R.id.imageview_cargo2);
		linear41 = (LinearLayout) findViewById(R.id.linear41);
		linear42 = (LinearLayout) findViewById(R.id.linear42);
		cargo3 = (LinearLayout) findViewById(R.id.cargo3);
		money_3 = (TextView) findViewById(R.id.money_3);
		imageview_cargo3 = (ImageView) findViewById(R.id.imageview_cargo3);
		cargo4 = (LinearLayout) findViewById(R.id.cargo4);
		money_4 = (TextView) findViewById(R.id.money_4);
		imageview_cargo4 = (ImageView) findViewById(R.id.imageview_cargo4);
		linear43 = (LinearLayout) findViewById(R.id.linear43);
		linear44 = (LinearLayout) findViewById(R.id.linear44);
		linear45 = (LinearLayout) findViewById(R.id.linear45);
		linear46 = (LinearLayout) findViewById(R.id.linear46);
		cargo5 = (LinearLayout) findViewById(R.id.cargo5);
		money_5 = (TextView) findViewById(R.id.money_5);
		imageview_cargo5 = (ImageView) findViewById(R.id.imageview_cargo5);
		cargo6 = (LinearLayout) findViewById(R.id.cargo6);
		money_6 = (TextView) findViewById(R.id.money_6);
		imageview_cargo6 = (ImageView) findViewById(R.id.imageview_cargo6);
		linear47 = (LinearLayout) findViewById(R.id.linear47);
		linear48 = (LinearLayout) findViewById(R.id.linear48);
		cargo7 = (LinearLayout) findViewById(R.id.cargo7);
		money_7 = (TextView) findViewById(R.id.money_7);
		imageview_cargo7 = (ImageView) findViewById(R.id.imageview_cargo7);
		cargo8 = (LinearLayout) findViewById(R.id.cargo8);
		money_8 = (TextView) findViewById(R.id.money_8);
		imageview_cargo8 = (ImageView) findViewById(R.id.imageview_cargo8);
		linear13 = (LinearLayout) findViewById(R.id.linear13);
		linear14 = (LinearLayout) findViewById(R.id.linear14);
		linear15 = (LinearLayout) findViewById(R.id.linear15);
		imageview8 = (ImageView) findViewById(R.id.imageview8);
		textview14 = (TextView) findViewById(R.id.textview14);
		textview16 = (TextView) findViewById(R.id.textview16);
		imageview9 = (ImageView) findViewById(R.id.imageview9);
		textview15 = (TextView) findViewById(R.id.textview15);
		
		webview1.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		back.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		image.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ViewActivity.class);
				i.putExtra("name", "equipment");
				startActivity(i);
			}
		});
		
		linear21.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), StoreinfoActivity.class);
				startActivity(i);
			}
		});
		
		linear32.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				good.setBackgroundColor(0xFF4CAF50);
				recommend.setBackgroundColor(0xFFFFFFFF);
				good_page.setVisibility(View.VISIBLE);
				recommend_page.setVisibility(View.GONE);
				good_page.setTranslationX((float)(500));
				_Animation();
			}
		});
		
		textview_recommend.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				recommend.setBackgroundColor(0xFF4CAF50);
				good.setBackgroundColor(0xFFFFFFFF);
				recommend_page.setVisibility(View.VISIBLE);
				good_page.setVisibility(View.GONE);
				recommend_page.setTranslationX((float)(500));
				_Animation();
			}
		});
		
		linear13.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SellerpageActivity.class);
				startActivity(i);
			}
		});
		
		linear15.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ChatActivity.class);
				startActivity(i);
			}
		});
		
		imageview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), SellerpageActivity.class);
				startActivity(i);
			}
		});
		
		imageview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ChatActivity.class);
				startActivity(i);
			}
		});
	}
	
	private void initializeLogic() {
		_Design();
		_URL_image();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _settings () {
		i.setClass(getApplicationContext(), SettingsActivity.class);
		startActivity(i);
	}
	
	
	public void _Animation () {
		Anima.setTarget(recommend_page);
		Anima.setPropertyName("translationX");
		Anima.setFloatValues((float)(-500), (float)(0));
		Anima.setDuration((int)(500));
		Anima.setInterpolator(new LinearInterpolator());
		Anima.start();
		Anima2.setTarget(good_page);
		Anima2.setPropertyName("translationX");
		Anima2.setFloatValues((float)(500), (float)(0));
		Anima2.setDuration((int)(500));
		Anima2.setInterpolator(new LinearInterpolator());
		Anima2.start();
	}
	
	
	public void _setPopUpWindow () {
		View popupView = getLayoutInflater().inflate(R.layout.popup, null);
		
		final PopupWindow popup = new PopupWindow(popupView, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, true);
		LinearLayout settings = popupView.findViewById(R.id.settings);
		LinearLayout ly = popupView.findViewById(R.id.bg);
		settings.setOnClickListener(new OnClickListener() { public void onClick(View view) {
				
				_settings();
				popup.dismiss();
			} });
		
		popup.showAtLocation(popupView, Gravity.RIGHT, 0, 0);
		
		android.graphics.drawable.GradientDrawable gn = new android.graphics.drawable.GradientDrawable ();
		gn.setColor (Color.parseColor("#FFFFFF"));
		gn.setCornerRadius (15);
		ly.setBackground (gn);
		ly.setElevation(5);
	}
	
	
	public void _URL_image () {
		Glide.with(getApplicationContext()).load(Uri.parse("https://www.linkpicture.com/q/20200806_103744.jpg")).into(imageview_cargo1);
		Glide.with(getApplicationContext()).load(Uri.parse("https://www.linkpicture.com/q/20200806_103845.jpg")).into(imageview_cargo2);
		Glide.with(getApplicationContext()).load(Uri.parse("https://www.linkpicture.com/q/20200806_103941.jpg")).into(imageview_cargo3);
		Glide.with(getApplicationContext()).load(Uri.parse("https://www.linkpicture.com/q/20200806_122300.jpg")).into(imageview_cargo4);
		Glide.with(getApplicationContext()).load(Uri.parse("https://www.linkpicture.com/q/20200806_103808.jpg")).into(imageview_cargo5);
		Glide.with(getApplicationContext()).load(Uri.parse("https://www.linkpicture.com/q/20200806_121938.jpg")).into(imageview_cargo6);
		Glide.with(getApplicationContext()).load(Uri.parse("https://www.linkpicture.com/q/20200806_122015.jpg")).into(imageview_cargo7);
		Glide.with(getApplicationContext()).load(Uri.parse("https://www.linkpicture.com/q/20200806_122328.jpg")).into(imageview_cargo8);
	}
	
	
	public void _imageview_zoom (final WebView _webview) {
		_webview.getSettings().setBuiltInZoomControls(true);
		_webview.getSettings().setDisplayZoomControls(false);
		_webview.getSettings().setLoadWithOverviewMode(true);
		_webview.getSettings().setUseWideViewPort(true);
	}
	
	
	public void _ClickEffect (final View _view) {
		TypedValue typedValue = new TypedValue();
		
		getApplicationContext().getTheme().resolveAttribute(16843868, typedValue, true);
		
		_view.setBackgroundResource(typedValue.resourceId);
		
		_view.setClickable(true);
	}
	
	
	public void _NavigationBar_Colors (final String _color) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.KITKAT) { 			Window w = this.getWindow(); 			w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS); 			w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); 			w.setNavigationBarColor(Color.parseColor(_color));
		}
	}
	
	
	public void _StatusBar_White (final View _view) {
		Window w = this.getWindow();w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS); w.setStatusBarColor(Color.parseColor("#FFFFFF"));
		_view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
	}
	
	
	public void _TransitionManager (final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _CardStyle (final View _view, final double _shadow, final double _radius, final String _color, final boolean _touch) {
		android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
		gd.setColor(Color.parseColor(_color));
		gd.setCornerRadius((int)_radius);
		_view.setBackground(gd);
		
		if (Build.VERSION.SDK_INT >= 21){
			_view.setElevation((int)_shadow);}
		if (_touch) {
			_view.setOnTouchListener(new View.OnTouchListener() {
				@Override
				public boolean onTouch(View v, MotionEvent event) {
					switch (event.getAction()){
						case MotionEvent.ACTION_DOWN:{
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues(0.9f);
							scaleX.setDuration(100);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues(0.9f);
							scaleY.setDuration(100);
							scaleY.start();
							break;
						}
						case MotionEvent.ACTION_UP:{
							
							ObjectAnimator scaleX = new ObjectAnimator();
							scaleX.setTarget(_view);
							scaleX.setPropertyName("scaleX");
							scaleX.setFloatValues((float)1);
							scaleX.setDuration(100);
							scaleX.start();
							
							ObjectAnimator scaleY = new ObjectAnimator();
							scaleY.setTarget(_view);
							scaleY.setPropertyName("scaleY");
							scaleY.setFloatValues((float)1);
							scaleY.setDuration(100);
							scaleY.start();
							
							break;
						}
					}
					return false;
				}
			});
		}
	}
	
	
	public void _Elevation (final View _view, final double _number) {
		
		_view.setElevation((int)_number);
	}
	
	
	public void _Design () {
		_Elevation(viewBar, 5);
		_Elevation(nav, 10);
		_CardStyle(linear14, 5, 50, "#4caf50", true);
		_CardStyle(linear21, 3, 50, "#4caf50", true);
		_CardStyle(linear22, 3, 50, "#FFFFFF", true);
		_StatusBar_White(background);
		_NavigationBar_Colors("#FFFFFF");
		_ClickEffect(image);
		_ClickEffect(back);
		_ClickEffect(imageview10);
		_ClickEffect(imageview3);
		_ClickEffect(imageview8);
		_ClickEffect(imageview9);
		good.setBackgroundColor(0xFFFFFFFF);
		good_page.setVisibility(View.GONE);
		_CardStyle(cargo1, 5, 15, "#FFFFFF", false);
		_CardStyle(cargo2, 5, 15, "#FFFFFF", false);
		_CardStyle(cargo3, 5, 15, "#FFFFFF", false);
		_CardStyle(cargo4, 5, 15, "#FFFFFF", false);
		_CardStyle(cargo5, 5, 15, "#FFFFFF", false);
		_CardStyle(cargo6, 5, 15, "#FFFFFF", false);
		_CardStyle(cargo7, 5, 15, "#FFFFFF", false);
		_CardStyle(cargo8, 5, 15, "#FFFFFF", false);
		_imageview_zoom(webview1);
		linear_webview.setVisibility(View.GONE);
		viewBar.setVisibility(View.VISIBLE);
		background.setVisibility(View.VISIBLE);
		nav.setVisibility(View.VISIBLE);
		android.graphics.drawable.GradientDrawable CRNKO = new android.graphics.drawable.GradientDrawable();
		CRNKO.setColor(Color.parseColor("#ffffff"));
		CRNKO.setCornerRadii(new float[]{ (float) 15,(float) 15,(float) 15,(float) 15,(float) 15,(float) 15,(float) 15,(float) 15 });
		CRNKO.setStroke((int) 2, Color.parseColor("#C62828"));
		lod50.setElevation((float) 0);
		lod50.setBackground(CRNKO);
		//Milz
		android.graphics.drawable.GradientDrawable CRNKO1 = new android.graphics.drawable.GradientDrawable();
		CRNKO1.setColor(Color.parseColor("#ffffff"));
		CRNKO1.setCornerRadii(new float[]{ (float) 15,(float) 15,(float) 15,(float) 15,(float) 15,(float) 15,(float) 15,(float) 15 });
		CRNKO1.setStroke((int) 2, Color.parseColor("#C62828"));
		lod100.setElevation((float) 0);
		lod100.setBackground(CRNKO1);
		//Milz
		_CardStyle(choice_more, 3, 15, "#4caf50", true);
		_Icon_Colour(imageview8, "#4caf50");
		_Icon_Colour(imageview9, "#4caf50");
		_Icon_Colour(back, "#4caf50");
		_Icon_Colour(imageview3, "#4caf50");
		_Icon_Colour(back, "#4caf50");
		_Icon_Colour(imageview10, "#4caf50");
	}
	
	
	public void _Icon_Colour (final ImageView _iconview, final String _colour) {
		_iconview.getDrawable().setColorFilter(Color.parseColor(_colour), PorterDuff.Mode.SRC_IN);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}