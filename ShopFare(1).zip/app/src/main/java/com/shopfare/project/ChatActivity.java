package com.shopfare.project;

import androidx.appcompat.app.AppCompatActivity;
import androidx.annotation.*;
import android.app.*;
import android.os.*;
import android.view.*;
import android.view.View.*;
import android.widget.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.webkit.*;
import android.animation.*;
import android.view.animation.*;
import java.util.*;
import java.util.regex.*;
import java.text.*;
import org.json.*;
import java.util.ArrayList;
import java.util.HashMap;
import android.widget.LinearLayout;
import androidx.cardview.widget.CardView;
import android.widget.ImageView;
import de.hdodenhof.circleimageview.*;
import android.widget.TextView;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import android.widget.EditText;
import android.view.View;
import androidx.palette.*;
import androidmads.library.qrgenearator.*;
import com.google.zxing.*;
import uk.co.senab.photoview.*;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.DialogFragment;


public class ChatActivity extends  AppCompatActivity  { 
	
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout toolbar;
	private LinearLayout linear1;
	private CardView cardview1;
	private ImageView imageview2;
	private CircleImageView circleimageview1;
	private LinearLayout linear2;
	private ImageView imageview3;
	private ImageView imageview4;
	private TextView textview2;
	private TextView textview3;
	private TextView textview4;
	private RecyclerView recyclerview1;
	private LinearLayout message_body_in_message;
	private ImageView media;
	private LinearLayout msg_spc;
	private EditText message;
	private ImageView sound;
	private ImageView send;
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.chat);
		initialize(_savedInstanceState);
		com.google.firebase.FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		
		toolbar = (LinearLayout) findViewById(R.id.toolbar);
		linear1 = (LinearLayout) findViewById(R.id.linear1);
		cardview1 = (CardView) findViewById(R.id.cardview1);
		imageview2 = (ImageView) findViewById(R.id.imageview2);
		circleimageview1 = (CircleImageView) findViewById(R.id.circleimageview1);
		linear2 = (LinearLayout) findViewById(R.id.linear2);
		imageview3 = (ImageView) findViewById(R.id.imageview3);
		imageview4 = (ImageView) findViewById(R.id.imageview4);
		textview2 = (TextView) findViewById(R.id.textview2);
		textview3 = (TextView) findViewById(R.id.textview3);
		textview4 = (TextView) findViewById(R.id.textview4);
		recyclerview1 = (RecyclerView) findViewById(R.id.recyclerview1);
		message_body_in_message = (LinearLayout) findViewById(R.id.message_body_in_message);
		media = (ImageView) findViewById(R.id.media);
		msg_spc = (LinearLayout) findViewById(R.id.msg_spc);
		message = (EditText) findViewById(R.id.message);
		sound = (ImageView) findViewById(R.id.sound);
		send = (ImageView) findViewById(R.id.send);
		
		sound.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
	}
	
	private void initializeLogic() {
		for(int _repeat12 = 0; _repeat12 < (int)(21); _repeat12++) {
			{
				HashMap<String, Object> _item = new HashMap<>();
				_item.put("key", "");
				listmap.add(_item);
			}
			
		}
		recyclerview1.setLayoutManager(new LinearLayoutManager(this));
		recyclerview1.setAdapter(new Recyclerview1Adapter(listmap));
		_NavStatusBarColor("#388e3c", "#f5f5f5");
		message_body_in_message.setElevation((float)5);
		_design();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			
			default:
			break;
		}
	}
	
	public void _RadiusGradient4 (final View _view, final String _color1, final String _color2, final double _lt, final double _rt, final double _rb, final double _lb, final double _border, final String _color3) {
		int[] colors = { Color.parseColor(_color1), Color.parseColor(_color2) }; android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colors);
		gd.setCornerRadii(new float[]{(int)_lt,(int)_lt,(int)_rt,(int)_rt,(int)_rb,(int)_rb,(int)_lb,(int)_lb});
		gd.setStroke((int) _border, Color.parseColor(_color3));
		_view.setBackground(gd);
	}
	
	
	public void _NavStatusBarColor (final String _color1, final String _color2) {
		if (Build.VERSION.SDK_INT > Build.VERSION_CODES.LOLLIPOP) {
			Window w = this.getWindow();	w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);	w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			w.setStatusBarColor(Color.parseColor("#" + _color1.replace("#", "")));	w.setNavigationBarColor(Color.parseColor("#" + _color2.replace("#", "")));
		}
	}
	
	
	public void _ClickEffect (final View _view) {
		TypedValue typedValue = new TypedValue();
		
		getApplicationContext().getTheme().resolveAttribute(16843868, typedValue, true);
		
		_view.setBackgroundResource(typedValue.resourceId);
		
		_view.setClickable(true);
	}
	
	
	public void _design () {
		_ClickEffect(imageview4);
		_ClickEffect(imageview3);
		_ClickEffect(imageview2);
		_ClickEffect(linear2);
	}
	
	
	public class Recyclerview1Adapter extends RecyclerView.Adapter<Recyclerview1Adapter.ViewHolder> {
		ArrayList<HashMap<String, Object>> _data;
		public Recyclerview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _inflater.inflate(R.layout.chatc, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear23 = (LinearLayout) _view.findViewById(R.id.linear23);
			final LinearLayout linear22 = (LinearLayout) _view.findViewById(R.id.linear22);
			final LinearLayout sender = (LinearLayout) _view.findViewById(R.id.sender);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview4 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview4);
			final LinearLayout linear3 = (LinearLayout) _view.findViewById(R.id.linear3);
			final LinearLayout linear4 = (LinearLayout) _view.findViewById(R.id.linear4);
			final LinearLayout wrap_sender = (LinearLayout) _view.findViewById(R.id.wrap_sender);
			final LinearLayout sn_reply_linear = (LinearLayout) _view.findViewById(R.id.sn_reply_linear);
			final TextView sn_message = (TextView) _view.findViewById(R.id.sn_message);
			final LinearLayout linear6 = (LinearLayout) _view.findViewById(R.id.linear6);
			final LinearLayout linear20 = (LinearLayout) _view.findViewById(R.id.linear20);
			final LinearLayout linear10 = (LinearLayout) _view.findViewById(R.id.linear10);
			final LinearLayout sn_image = (LinearLayout) _view.findViewById(R.id.sn_image);
			final LinearLayout linear11 = (LinearLayout) _view.findViewById(R.id.linear11);
			final TextView sn_reply_text = (TextView) _view.findViewById(R.id.sn_reply_text);
			final TextView sn_reply_name = (TextView) _view.findViewById(R.id.sn_reply_name);
			final TextView textview7 = (TextView) _view.findViewById(R.id.textview7);
			final TextView textview6 = (TextView) _view.findViewById(R.id.textview6);
			final ImageView imageview3 = (ImageView) _view.findViewById(R.id.imageview3);
			final ImageView sn_send_type = (ImageView) _view.findViewById(R.id.sn_send_type);
			final TextView sn_time = (TextView) _view.findViewById(R.id.sn_time);
			final ImageView sn_seen = (ImageView) _view.findViewById(R.id.sn_seen);
			final ImageView sn_corner_img = (ImageView) _view.findViewById(R.id.sn_corner_img);
			final de.hdodenhof.circleimageview.CircleImageView circleimageview1 = (de.hdodenhof.circleimageview.CircleImageView) _view.findViewById(R.id.circleimageview1);
			final LinearLayout receiver = (LinearLayout) _view.findViewById(R.id.receiver);
			final LinearLayout linear12 = (LinearLayout) _view.findViewById(R.id.linear12);
			final LinearLayout linear13 = (LinearLayout) _view.findViewById(R.id.linear13);
			final ImageView rv_corner_img = (ImageView) _view.findViewById(R.id.rv_corner_img);
			final LinearLayout wrap_receiver = (LinearLayout) _view.findViewById(R.id.wrap_receiver);
			final LinearLayout rv_reply_linear = (LinearLayout) _view.findViewById(R.id.rv_reply_linear);
			final TextView rv_message = (TextView) _view.findViewById(R.id.rv_message);
			final LinearLayout linear16 = (LinearLayout) _view.findViewById(R.id.linear16);
			final LinearLayout rv_image = (LinearLayout) _view.findViewById(R.id.rv_image);
			final LinearLayout linear18 = (LinearLayout) _view.findViewById(R.id.linear18);
			final LinearLayout linear21 = (LinearLayout) _view.findViewById(R.id.linear21);
			final ImageView imageview6 = (ImageView) _view.findViewById(R.id.imageview6);
			final ImageView rv_reply_type = (ImageView) _view.findViewById(R.id.rv_reply_type);
			final LinearLayout linear19 = (LinearLayout) _view.findViewById(R.id.linear19);
			final TextView rv_reply_text = (TextView) _view.findViewById(R.id.rv_reply_text);
			final TextView rv_reply_name = (TextView) _view.findViewById(R.id.rv_reply_name);
			final TextView textview11 = (TextView) _view.findViewById(R.id.textview11);
			final TextView textview12 = (TextView) _view.findViewById(R.id.textview12);
			final TextView rv_time = (TextView) _view.findViewById(R.id.rv_time);
			final ImageView rv_seen = (ImageView) _view.findViewById(R.id.rv_seen);
			
			sn_reply_linear.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, 0xFF000000, 0xFFC8E6C9));
			rv_reply_linear.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)20, (int)0, 0xFF000000, 0xFFF5F5F5));
			_RadiusGradient4(wrap_sender, "#a5d6a7", "#a5d6a7", 20, 20, 0, 20, 0, "#ffffff");
			_RadiusGradient4(wrap_receiver, "#eeeeee", "#eeeeee", 0, 20, 20, 20, 0, "#ffffff");
			sn_corner_img.setColorFilter(0xFFA5D6A7, PorterDuff.Mode.MULTIPLY);
			rv_corner_img.setColorFilter(0xFFEEEEEE, PorterDuff.Mode.MULTIPLY);
			sn_seen.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
			if (_position == 0) {
				sn_message.setText("Hello");
				rv_message.setText("Hi");
				sn_reply_linear.setVisibility(View.GONE);
				rv_reply_linear.setVisibility(View.GONE);
			}
			if (_position == 1) {
				sn_message.setText("i tried calling you some time ago");
				rv_message.setText("Oww sorry i was not around");
				sn_reply_linear.setVisibility(View.GONE);
				rv_reply_linear.setVisibility(View.GONE);
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder{
			public ViewHolder(View v){
				super(v);
			}
		}
		
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input){
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels(){
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels(){
		return getResources().getDisplayMetrics().heightPixels;
	}
	
}